local ZGV = ZygorGuidesViewer
if not ZGV then return end

-----------------------------------------
-- LOCAL REFERENCES
-----------------------------------------

EMPTY_STRING = ""
LEFT_MOUSE_BUTTON = 1
RIGHT_MOUSE_BUTTON = 2
MIDDLE_MOUSE_BUTTON = 3