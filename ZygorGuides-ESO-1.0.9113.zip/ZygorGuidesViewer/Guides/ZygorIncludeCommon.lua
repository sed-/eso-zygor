local ZGV = ZygorGuidesViewer
if not ZGV then return end
if ZGV:DoMutex("IncludesCommon") then return end

ZGV:RegisterInclude("skyshards",[[
		step
			.' Hello
]])