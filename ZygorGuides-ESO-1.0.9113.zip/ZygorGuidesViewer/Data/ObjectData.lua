local ZGV = ZygorGuidesViewer
if not ZGV then return end

ZGV._ObjectDataCommon = [[
The Wailing Prison=3360001
The Bleeding Forge=3360002
The Ashen Mines=3360003
The Towers of Eyes=3360004
Coldharbour Sentinel=3360005
The Undercroft=3360006
The Prophet's Cell=3360007
Daedric Anchor Pinion=3360008
The Anchor Mooring=3360009
Skyshard=3360010
Anchor Control Device=3360011
Escape to Tamriel=3360012
Chest=3360013
Bow=3360014
The Prophet's Cage=3360015
Sword and Shield=3360016
Two-Handed Mace=3360017
Restoration Staff=3360018
Frost Staff=3360019
Twin Axes=3360020
Sword=3360021
Spike Trap=3360022
Take and Equip a Weapon=3360023
Ice Staff=3360024
]]