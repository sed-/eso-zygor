local ZGV = ZygorGuidesViewer
if not ZGV then return end

-- 3 diget zone id then 4 diget uniqueid

ZGV._NpcDataCommon = [[
The Prophet=3360001
Soul Shriven=3360002
Er-Jaseen=3360003
Skeletal Warrior=3360004
Skeletal Archer=3360005
Lyris Titanborn=3360006
Familiar=3360007
Flame Atronach=3360008
Feral Shriven=3360009
Cadwell=3360010
Anchor Guardian=3360011
Gruzdash=3360012
Galynne=3360013
Child of Bones=3360014
Skeletal Cryomancer=3360015
Skeletal Pyromancer=3360016
]]