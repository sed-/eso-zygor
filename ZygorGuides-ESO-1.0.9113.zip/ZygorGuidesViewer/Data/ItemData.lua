local ZGV = ZygorGuidesViewer
if not ZGV then return end

ZGV._ItemData = [[
]]