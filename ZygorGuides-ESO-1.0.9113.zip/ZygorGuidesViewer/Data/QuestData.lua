local ZGV = ZygorGuidesViewer
if not ZGV then return end

-- 3 diget zone id then 4 diget uniqueid

ZGV._QuestDataCommon = [[
Soul Shriven in Coldharbour=3360001

The Hollow City=1540001
The Army of Meridia=1540002
Truth, Lies, and Prisoners=1540003
Through the Daedric Lens=1540004
Wisdom of the Ages=1540005
The Library of Dusk=1540006
Into the Woods=1540007
The Shadow's Embrace=1540008
Light from the Darkness=1540009
Council of the Five Companions=1540010
The Soul-Meld Mage=1540011
Hall of Judgment=1540012
Special Blend=1540013
Vanus Unleashed=1540014
Breaking the Shackle=1540015
Crossing the Chasm=1540016
Saving Stibbons=1540017
The Harvest Heart=1540018
The Citadel Must Fall=1540019
What the Heart Wants=1540020
A Graveyard of Ships=1540021
Old Bones=1540022
The Final Assault=1540023
The Endless War=1540024
A Thorn in Your Side=1540025
Between Blood and Bone=1540026
God of Schemes=1540027

]]